<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>FrameworkSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-06-15T18:25:46</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>3ce11527-83d5-406a-a0b5-5e28ff340b52</testSuiteGuid>
   <testCaseLink>
      <guid>ca7838b2-273f-4f02-89ec-c1999f8542c5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Framework/Framing</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
